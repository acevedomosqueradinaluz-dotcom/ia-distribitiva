import os
import time
import pandas as pd
from multiprocessing import Pool, cpu_count

# Función que ejecutará cada núcleo (nodo) en paralelo
def procesar_fragmento(df_fragmento):
    """
    Simula el comportamiento de un nodo distribuido analizando un fragmento del inventario.
    Calcula métricas clave como el total de alimentos por categoría y el estado de prioridad.
    """
    # Simulación de un cálculo analítico de distribución
    resumen = df_fragmento.groupby('Categoria').agg(
        Total_Kilos=('Kilos', 'sum'),
        Total_Donaciones=('ID_Donacion', 'count')
    ).reset_index()
    return resumen

def generar_datos_prueba():
    """Genera un archivo CSV simulado con miles de donaciones del Banco de Alimentos."""
    import random
    categorias = ['Granos', 'Lácteos', 'Frutas y Verduras', 'Cárnicos', 'Enlatados', 'Abarrotes']
    estados = ['Crítico', 'Estable', 'Abundante']
    
    data = {
        'ID_Donacion': [f"DON-{100000 + i}" for i in range(50000)],
        'Categoria': [random.choice(categorias) for _ in range(50000)],
        'Kilos': [random.randint(10, 500) for _ in range(50000)],
        'Prioridad': [random.choice(estados) for _ in range(50000)]
    }
    df = pd.DataFrame(data)
    df.to_csv('inventario_banco_alimentos.csv', index=False)
    print("[NODO CENTRAL] Archivo 'inventario_banco_alimentos.csv' generado con 50,000 registros.")

if __name__ == '__main__':
    print("=== SISTEMA DISTRIBUIDO DE PROCESAMIENTO PARALELO ===")
    
    # 1. Preparar datos si no existen
    if not os.path.exists('inventario_banco_alimentos.csv'):
        generar_datos_prueba()
        
    # Cargar base de datos (Nodo Central)
    print("\n[NODO CENTRAL] Cargando base de datos principal...")
    df_principal = pd.read_csv('inventario_banco_alimentos.csv')
    
    # Determinar número de núcleos utilizables (Nodos de procesamiento)
    num_procesadores = cpu_count()
    print(f"[ARQUITECTURA] Detectados {num_procesadores} núcleos disponibles en esta computadora.")
    
    # --- PROCESAMIENTO TRADICIONAL (SECUENCIAL) ---
    print("\n--- Iniciando Procesamiento Tradicional (1 solo núcleo) ---")
    inicio_sec = time.time()
    resultado_sec = procesar_fragmento(df_principal)
    fin_sec = time.time()
    tiempo_sec = fin_sec - inicio_sec
    print(f"[RENDIMIENTO] Procesamiento secuencial terminado en: {tiempo_sec:.4f} segundos.")
    
    # --- PROCESAMIENTO DISTRIBUIDO (PARALELO) ---
    print(f"\n--- Iniciando Procesamiento Distribuido ({num_procesadores} núcleos en paralelo) ---")
    inicio_par = time.time()
    
    # Dividir el DataFrame principal en fragmentos (Splitter)
    fragmentos = [df_principal[i::num_procesadores] for i in range(num_procesadores)]
    print(f"[SPLITTER] Datos divididos en {len(fragmentos)} bloques idénticos.")
    
    # Crear el pool de procesos (Distribución a los nodos trabajadores)
    with Pool(processes=num_procesadores) as pool:
        resultados_nodos = pool.map(procesar_fragmento, fragmentos)
        
    # Consolidar los reportes de todos los nodos (Reducer)
    resultado_final_par = pd.concat(resultados_nodos).groupby('Categoria').sum().reset_index()
    
    fin_par = time.time()
    tiempo_par = fin_par - inicio_par
    print(f"[RENDIMIENTO] Procesamiento distribuido terminado en: {tiempo_par:.4f} segundos.")
    
    # 2. Mostrar métricas de optimización
    print("\n================ REPORTES Y CONCLUSIONES ================")
    print(resultado_final_par.to_string(index=False))
    
    mejora = (tiempo_sec / tiempo_par) if tiempo_par > 0 else 1
    print(f"\n[ÉXITO] ¡El procesamiento paralelo fue {mejora:.2f} veces más rápido que el secuencial!")
    print("========================================================")
