# Proyecto: IA Distributiva - Procesamiento de Datos en Paralelo 📊

Este proyecto simula la arquitectura de un sistema de **IA Distributiva** mediante la computación en paralelo utilizando Python. Está diseñado conceptualmente para optimizar la gestión de datos de inventario y donaciones masivas, inspirado en las necesidades del **Banco de Alimentos de Cali**.

## 🚀 Cómo ejecutar en Visual Studio Code

1. Extrae el contenido de este archivo ZIP en una carpeta de tu preferencia.
2. Abre Visual Studio Code, ve a **Archivo -> Abrir carpeta** y selecciona la carpeta extraída.
3. Asegúrate de tener instalada la librería `pandas` en tu entorno:
   ```bash
   pip install pandas
   ```
4. Ejecuta el archivo principal ejecutando en la consola de VS Code:
   ```bash
   python main.py
   ```

## 🛠️ Explicación de la Lógica Distribuida
El programa genera automáticamente un archivo de simulación con **50,000 registros de alimentos** y compara el tiempo de procesamiento tradicional frente al procesamiento distribuido en los múltiples núcleos de tu procesador.
